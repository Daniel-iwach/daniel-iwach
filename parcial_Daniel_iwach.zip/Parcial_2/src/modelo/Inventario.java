/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;


public class Inventario<T> {
    private static final Long serialVersion=1L;
    private List<T> lista;


    public Inventario() {
        this.lista = new ArrayList<>();
    }
    
    public void agregar(T elemento){
        if(elemento == null){
            throw new NullPointerException();
        }
        lista.add((T) elemento);
    }
    
    public void eliminar(int indice){
        if(indice<0 || indice>= lista.size()){
            throw new IndexOutOfBoundsException();
        }
        lista.remove(indice);
    }
    
    public void listar(){
        for (T t : lista) {
            System.out.println(t);
        }
    }
    
     public void ordenar(){
        if(!lista.isEmpty() && lista.get(0) instanceof Comparable){
            ordenar((Comparator<T>) Comparator.naturalOrder());
        }
     }
     
     public void ordenar(Comparator<T>comparador){
       lista.sort(comparador);
     }
     
     public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> aux = new ArrayList<>();
        for (T t : lista) {
            if (criterio.test(t)){
                aux.add(t);            
            }
        }
        return aux;
    }
     public void paraCadaElemento(Consumer<T>accion) {
        for(T item : lista){
            accion.accept(item);
        } 
    }
     public List<T> transformar(Function<? super T, ? extends T> transformacion) {
        List<T> toReturn = new ArrayList<>();
        for (T item : lista) {
            toReturn.add(transformacion.apply(item));
        }
        return toReturn;
    }
     public void guardarEnArchivo(String path) {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            salida.writeObject(lista);
        } catch (IOException ex) {
            System.out.println("Error al guardar en binario: " + ex.getMessage());
        }
    }
     public void cargarDesdeArchivo(String path) {
    try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
        // Actualizamos la lista interna con los objetos deserializados
        lista = (List<T>) entrada.readObject();
    } catch (IOException | ClassNotFoundException ex) {
        System.out.println("Error al cargar desde binario: " + ex.getMessage());
    }
}

     public void guardarEnCSV(String path){
        try(BufferedWriter bw= new BufferedWriter(new FileWriter(path))){
                bw.write("ID, NOMBRE, CLASE, NIVEL"+ "\n");
                for (T elemento : lista) {
                    if(elemento instanceof Personaje libro){
                        bw.write(libro.toCSV()+"\n");   
                    } 
                }
            }catch(IOException ex) {
                System.out.println(ex.getMessage());
            }
        }
     
    public List<Personaje> cargarDesdeCSV(String path) throws IOException {
    List<Personaje> toReturn = new ArrayList<>();
    try (BufferedReader br = new BufferedReader(new FileReader(path))) {
        String linea;
        br.readLine();  

        while ((linea = br.readLine()) != null) {
            
            if (linea.endsWith("\n")) {
                linea = linea.substring(0, linea.length() - 1);
            }

            
            Personaje personaje = new Personaje(0, "", Clase.GUERRERO, 0);  
            personaje = personaje.fromCSV(linea);  
            if (personaje != null) { 
                toReturn.add(personaje);
            }
        }
    } catch (IOException ex) {
        System.err.println("Error al leer el archivo: " + ex.getMessage());
    }
    return toReturn;  
}

}
    

    
    
    

