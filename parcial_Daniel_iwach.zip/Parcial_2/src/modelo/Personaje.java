/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.io.Serializable;
import modelo.Clase;

/**
 *
 * @author Dani
 */
public class Personaje implements Comparable<Personaje>,CSVSerializable, Serializable {
    private int id;
    private String nombre;
    private Clase clase;
    private int nivel;

    public Personaje(int id, String nombre, Clase clase, int nivel) {
        validarParametros(id, nombre, clase, nivel);
        this.id = id;
        this.nombre = nombre;
        this.clase = clase;
        this.nivel = nivel;
    }
    private void validarParametros(int id, String nombre, Clase clase, int nivel) {
        // Validación del id
        if (id <= 0) {
            throw new IllegalArgumentException("El id debe ser un número positivo.");
        }

        // Validación del nombre
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede ser nulo o vacío.");
        }

        // Validación de la clase
        if (clase == null) {
            throw new IllegalArgumentException("La clase no puede ser nula.");
        }

        // Validación del nivel
        if (nivel <= 0) {
            throw new IllegalArgumentException("El nivel debe ser un número positivo.");
        }
    }

    @Override
    public String toString() {
        return "id=" + id + ", nombre=" + nombre + ", clase=" + clase + ", nivel=" + nivel + '}';
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public int getNivel() {
        return nivel;
    }

    public Clase getClase() {
        return clase;
    }

    @Override
    public int compareTo(Personaje o) {
        return this.nombre.compareTo(o.nombre);
    }

    
    @Override
    public Personaje fromCSV(String linea) {
        String[] values = linea.split(",");
        if (values.length != 4) {
            throw new IllegalArgumentException("Formato de línea CSV incorrecto");
        }
        int id = Integer.parseInt(values[0].trim());
        String nombre = values[1].trim();
        Clase categoria = Clase.valueOf(values[2].trim().toUpperCase());
        int nivel = Integer.parseInt(values[3].trim());
        return new Personaje(id, nombre, categoria, nivel);
    }

    

    public String toCSV() {
       return  id +","+nombre+","+clase.toString()+","+nivel;
    }
    
}
