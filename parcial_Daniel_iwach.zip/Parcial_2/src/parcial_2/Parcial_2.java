/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package parcial_2;

import java.io.IOException;
import modelo.Clase;
import modelo.Inventario;
import modelo.Personaje;

/**
 *
 * @author Dani
 */
public class Parcial_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {

        // Crear un inventario de personajes jugables
        Inventario<Personaje> inventarioPersonajes = new Inventario<>();
        inventarioPersonajes.agregar(new Personaje(1, "Aragorn", Clase.GUERRERO,20));
        inventarioPersonajes.agregar(new Personaje(2, "Gandalf", Clase.MAGO, 50));
        inventarioPersonajes.agregar(new Personaje(3, "Legolas", Clase.ARQUERO,25));
        inventarioPersonajes.agregar(new Personaje(4, "Frodo", Clase.GUERRERO,10));
        inventarioPersonajes.agregar(new Personaje(5, "Saruman", Clase.MAGO, 40));
        inventarioPersonajes.agregar(new Personaje(6, "Robin Hood", Clase.ARQUERO,30));
        // Mostrar todos los personajes en el inventario
        System.out.println("Inventario de personajes:");
        inventarioPersonajes.paraCadaElemento(personaje ->System.out.println(personaje));
        // Ordenar personajes de manera natural (por nombre)
        System.out.println("\nPersonajes ordenados por nombre (orden natural):");
        inventarioPersonajes.ordenar();
        inventarioPersonajes.paraCadaElemento(personaje ->System.out.println(personaje));
        // Ordenar personajes por nivel utilizando un Comparator
        System.out.println("\nPersonajes ordenados por nivel:");
        inventarioPersonajes.ordenar((p1, p2) -> Integer.compare(p1.getNivel(), p2.getNivel()));
        inventarioPersonajes.paraCadaElemento(personaje -> System.out.println(personaje));
        // Filtrar personajes de clase MAGO
        System.out.println("\nPersonajes de la clase MAGO:");
        inventarioPersonajes.filtrar(personaje -> personaje.getClase().equals(Clase.MAGO))
                .forEach(personaje -> System.out.println(personaje));
        // Transformar personajes: aumentar nivel en +5
        System.out.println("\nAumentando nivel de todos los personajes en +5:");
        inventarioPersonajes.transformar(personaje -> {
            personaje.setNivel(personaje.getNivel() + 5);
            return personaje;
        });
        inventarioPersonajes.paraCadaElemento(personaje ->System.out.println(personaje));
        // Guardar el inventario en un archivo binario
        inventarioPersonajes.guardarEnArchivo("src/data/personajes.dat");
        
        // Cargar el inventario desde el archivo binario
        Inventario<Personaje> inventarioCargado = new Inventario<>();
        inventarioCargado.cargarDesdeArchivo("src/data/personajes.dat");
        System.out.println("\nPersonajes cargados desde archivo binario:");
        inventarioCargado.paraCadaElemento(personaje ->System.out.println(personaje));
        
        // Guardar el inventario en un archivo CSV
        inventarioPersonajes.guardarEnCSV("src/data/personajes.csv");
        
        // Cargar el inventario desde el archivo CSV
        inventarioCargado.cargarDesdeCSV("src/data/personajes.csv");
        System.out.println("\nPersonajes cargados desde archivo CSV:");
        inventarioCargado.paraCadaElemento(personaje ->System.out.println(personaje));
    }
}
    
