
package services;

import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import module.Evento;


public interface Gestionable<T> {
     void agregar(Evento evento);  
     T obtener(int indice);
     void eliminar(int índice); 
     List<T> filtrar(Predicate<T> criterio); 
     void ordenar();  
     void ordenar(Comparator<T> comparador);
     void limpiar();
     void guardarEnBinario(String path);
     void cargarDesdeBinario(String path); 
     void guardarEnCSV(String path);
     void cargarDesdeCSV(String path,Function<String,T> funcion);
     void mostrarTodos();
}