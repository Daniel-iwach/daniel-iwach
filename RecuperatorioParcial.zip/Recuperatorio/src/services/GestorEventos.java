
package services;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import module.Evento;


public class GestorEventos<T extends Comparable<T> & CSVSerializable> implements Gestionable<T>, Serializable{
    private List<T>inventario;

    public GestorEventos() {
        inventario = new ArrayList<>();
    }
    
    @Override
    public void mostrarTodos(){
        for (T evento : inventario) {
            System.out.println(evento);
        }
    }

    @Override
    public void agregar(Evento evento) {
        if(evento==null){
            throw new IllegalArgumentException("evento para cargar invalido");
        }
        inventario.add((T) evento);
        
    }

    @Override
    public T obtener(int indice) {
        validarIndice(indice);
       return  (T) inventario.get(indice); 
    }

    @Override
    public void eliminar(int índice) {
        validarIndice(índice);
        inventario.remove(índice);
    }
    
    private void validarIndice(int indice){
        if(indice<0 || indice>inventario.size()-1){
            throw new IllegalArgumentException("indice invalido");
        }
    }

    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        if(criterio==null){
            throw new IllegalArgumentException("criterio invalido");
        }
        List<T> aux= new ArrayList<>();
        for (T evento : inventario) {
            if(criterio.test((T) evento)){
                aux.add((T) evento);
            }
        }
        return aux;
    }      

    @Override
    public void ordenar() {
        ordenar(Comparator.naturalOrder());
    }

    @Override
    public void ordenar(Comparator<T> comparador) {
        if(comparador==null){
            throw new IllegalArgumentException("comparador invalido");
        }
        inventario.sort(comparador);
        
    }

    @Override
    public void limpiar() {
        inventario.clear();
        
    }

    @Override
    public void guardarEnBinario(String path) {
         try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            salida.writeObject(inventario);
        } catch (IOException ex) {
            System.out.println("Error al guardar en binario: " + ex.getMessage());
        }
    }

    @Override
    public void cargarDesdeBinario(String path) {
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
            inventario = (List<T>) entrada.readObject();
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println("Error al cargar desde binario: " + ex.getMessage());
        }
    }

    @Override
    public void guardarEnCSV(String path) {
        boolean encabezado=true;
         try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            for (T elemento: inventario) {
                if(encabezado==true){
                    encabezado=false;
                    bw.write(elemento.toHeaderCSV());
                }
                bw.write(elemento.toCSV() + "\n");
            }
            
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
            throw new RuntimeException("Error en archivo.");
        }
    }

    @Override
    public void cargarDesdeCSV(String path,Function<String,T> funcion) {
        inventario.clear();
        
        try (BufferedReader bf = new BufferedReader(new FileReader(path))) {
            String linea;
            bf.readLine();
            while ((linea = bf.readLine()) != null) {
                inventario.add((T) funcion.apply(linea));
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
            throw new RuntimeException("Error en archivo.");
        }
    }
}
    

