
package module;

import java.io.Serializable;
import java.time.LocalDate;
import services.CSVSerializable;


public class EventoMusical extends Evento implements Comparable<EventoMusical>,Serializable{
    private static final long serialVersionUID = 1L;
    private String artista;
    private GeneroMusical genero;

    public EventoMusical(int id, String nombre, LocalDate fecha, String artista, GeneroMusical genero) {
        super(id, nombre, fecha);
        validarAtributos(artista,genero);
        this.artista = artista;
        this.genero = genero;
    }
    
    private void validarAtributos(String artista, GeneroMusical genero){
        validarArtista(artista);
        validarGenero(genero);
    }
 
    private void validarArtista(String artista) {
        if (artista == null || artista.isEmpty()) {
            throw new IllegalArgumentException("El nombre del artista no puede estar vacío.");
        }
    }

    private void validarGenero(GeneroMusical genero) {
        if (genero == null) {
            throw new IllegalArgumentException("El género musical no puede ser nulo.");
        }
    }

    @Override
    public int compareTo(EventoMusical evento) {
        return this.getFecha().compareTo(evento.getFecha());
    }

    public GeneroMusical getGenero() {
        return genero;
    }

    public String getArtista() {
        return artista;
    }

    @Override
    public String toString() {
        return  super.toString()+ ", artista=" + artista + ", genero=" + genero;
    }
    

    @Override
    public String toCSV() {
        return super.getId()+","+super.getNombre()+","+super.getFecha()+","+artista+","+genero;
        
    }
    
    public static EventoMusical fromCSV(String linea) {
        String[] values = linea.split(",");
        if (values.length != 5) {
            throw new IllegalArgumentException("Error en la linea csv.");
        }
        int id = Integer.parseInt(values[0]);
        String nombre = values[1];
        LocalDate fecha = LocalDate.parse(values[2]);
        String artista = values[3];
        GeneroMusical generoMusical = GeneroMusical.valueOf(values[4]);
        return new EventoMusical(id, nombre, fecha, artista, generoMusical);
    }

    @Override
    public String toHeaderCSV() {
        return "id, nombre, fecha, artista, generoMusical\n";
    }
    
    
}
