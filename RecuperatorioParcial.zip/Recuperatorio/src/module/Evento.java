/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package module;

import java.io.Serializable;
import java.time.LocalDate;
import services.CSVSerializable;


public abstract class Evento implements CSVSerializable, Serializable{
    private int id;
    private String nombre;
    private LocalDate fecha;

    public Evento(int id, String nombre, LocalDate fecha) {
        validarAtributos(id, nombre, fecha);
        this.id = id;
        this.nombre = nombre;
        this.fecha = fecha;
    }
    
    private void validarAtributos(int id, String nombre, LocalDate fecha){
        validarId(id);
        validarNombre(nombre);
        validarFecha(fecha);
    }
    
    private void validarId(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("El id debe ser mayor que cero.");
        }
    }
    
    private void validarNombre(String nombre) {
        if (nombre == null || nombre.isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío.");
        }
    }
    
    private void validarFecha(LocalDate fecha) {
        if (fecha == null) {
            throw new IllegalArgumentException("La fecha no puede ser nula");
        }
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    @Override
    public String toString() {
        return "id=" + id + ", nombre=" + nombre + ", fecha=" + fecha;
    }
    
    
    
}
